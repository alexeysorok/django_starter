from django.contrib import admin
from lesson_8.models import *

admin.site.register(GamerLibraryModel)
admin.site.register(GameModel)
admin.site.register(GamerModel)