from django.apps import AppConfig


class Lesson8Config(AppConfig):
    name = 'lesson_8'
