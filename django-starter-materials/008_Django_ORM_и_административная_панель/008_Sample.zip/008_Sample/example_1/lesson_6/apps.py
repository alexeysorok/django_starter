from django.apps import AppConfig


class Lesson6Config(AppConfig):
    name = 'lesson_6'
