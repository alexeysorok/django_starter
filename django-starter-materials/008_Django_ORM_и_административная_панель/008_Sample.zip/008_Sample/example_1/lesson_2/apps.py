from django.apps import AppConfig


class Lesson2Config(AppConfig):
    name = 'lesson_2'
