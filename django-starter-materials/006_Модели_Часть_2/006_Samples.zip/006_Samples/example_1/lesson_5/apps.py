from django.apps import AppConfig


class Lesson5Config(AppConfig):
    name = 'lesson_5'
