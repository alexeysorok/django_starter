from django.apps import AppConfig


class Lesson9Config(AppConfig):
    name = 'lesson_9'
