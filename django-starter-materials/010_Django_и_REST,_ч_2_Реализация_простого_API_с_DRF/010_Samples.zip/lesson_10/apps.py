from django.apps import AppConfig


class Lesson10Config(AppConfig):
    name = 'lesson_10'
