from django.apps import AppConfig


class Lesson3Config(AppConfig):
    name = 'lesson_3'
