from django.apps import AppConfig


class Lesson1Config(AppConfig):
    name = 'lesson_1'
